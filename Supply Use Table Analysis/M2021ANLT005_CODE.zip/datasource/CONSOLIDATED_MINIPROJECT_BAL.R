#Data import
library(tidyverse) 
library(DataExplorer)
library(ggplot2)


df <- read.csv("D:/ANUPAM/study/sem1/Course/1 Mathematics for Analytics/miniproject_Dr mansi/bkp/datasource/bal_table.csv", encoding = "UTF-8")
df<- df[!df$Sector=="",]

head(df)   #By default it shows the first 6 rows in a dataframe
colnames(df)
unique(df$Sector)

########################################1. Sectorwise###########################

####################################TOP 5 PRIMARY SECTOR###########################3
theme_set(theme_bw())
options(scipen = 100000000) #turns off exponential scale




df %>% 
  top_n(5,TOTAL_PRIMARY)%>%
  ggplot(aes(reorder(Product, OVERALL), OVERALL, fill = OVERALL))+
  geom_col(show.legend = TRUE, width = 0.9)+
  geom_text(mapping = aes(label= OVERALL), position = position_dodge())+
  theme_minimal()+
  theme(axis.text.x = element_text(size = 5))+
  labs(x = NULL, y = "(TOP 5) TOTAL VALUE-PRIMARY")+
  scale_fill_gradient(low = "orange", high = "orangered4")+
  theme(axis.line.y = element_line(colour = "darkslategray"),
        axis.ticks.x = element_line(colour = "darkslategray"))


####################################TOP 5 SECONDARY###########################3
theme_set(theme_bw())
options(scipen = 100000000) #turns off exponential scale
df %>% 
  top_n(5,TOTAL_SECONDARY)%>%
  ggplot(aes(reorder(Product, OVERALL), OVERALL, fill = OVERALL))+
  geom_col(show.legend = TRUE, width = 0.9)+
  geom_text(mapping = aes(label= OVERALL), position = position_dodge())+
  theme_minimal()+
  theme(axis.text.x = element_text(size = 5))+
  labs(x = NULL, y = "(TOP 5) TOTAL VALUE-SECONDARY")+
  scale_fill_gradient(low = "orange", high = "orangered4")+
  theme(axis.line.y = element_line(colour = "darkslategray"),
        axis.ticks.x = element_line(colour = "darkslategray"))


####################################TERTIARY SECTOR###########################3
theme_set(theme_bw())
options(scipen = 100000000) #turns off exponential scale
df %>% 
  top_n(5,TOTAL_TERTIARY)%>%
  ggplot(aes(reorder(Product, OVERALL), OVERALL, fill = OVERALL))+
  geom_col(show.legend = TRUE, width = 0.9)+
  geom_text(mapping = aes(label= OVERALL), position = position_dodge())+
  theme_minimal()+
  theme(axis.text.x = element_text(size = 5))+
  labs(x = NULL, y = "(TOP 5) TOTAL VALUE-TERTIARY")+
  scale_fill_gradient(low = "orange", high = "orangered4")+
  theme(axis.line.y = element_line(colour = "darkslategray"),
        axis.ticks.x = element_line(colour = "darkslategray"))
########################################1. Sectorwise###########################


#########################################2. piechart#######################
# Sector wise supply distribution of amount on Pie-Chart
df <- read.csv("D:/ANUPAM/study/sem1/Course/1 Mathematics for Analytics/miniproject_Dr mansi/bkp/datasource/bal_table.csv", encoding = "UTF-8")
df<- df[!df$Sector=="",]

head(df)   #By default it shows the first 6 rows in a dataframe
colnames(df)
unique(df$Sector)

# Sector wise supply distribution of amount on Pie-Chart
data <- data.frame(
  category=c("Primary Sector", "Secondary Sector", "Tertiary Sector"),
  count=c(sum(df$TOTAL_PRIMARY), sum(df$TOTAL_SECONDARY), sum(df$TOTAL_TERTIARY)))

data$fraction = data$count / sum(data$count)
data$ymax = cumsum(data$fraction)
data$ymin = c(0, head(data$ymax, n=-1))
data$labelPosition <- (data$ymax + data$ymin) / 2
data$label <- paste0(data$category, "\n Rs.", data$count, "Lacs")
ggplot(data, aes(ymax=ymax, ymin=ymin, xmax=4, xmin=3, fill=category)) +
  geom_rect() +
  geom_label( x=3.7, aes(y=labelPosition, label=label), size=3) +
  scale_fill_brewer(palette=2) +
  coord_polar(theta="y") +
  scale_fill_viridis_d(option="plasma")+
  theme_void() +
  theme(legend.position = "none") +
  labs(title="Sectorwise distribution (BP)")

#########################################2. piechart_closing#######################

#########################################3. agr-mining-man-ser TOP10_opening#######################

df <- read.csv("D:/ANUPAM/study/sem1/Course/1 Mathematics for Analytics/miniproject_Dr mansi/bkp/datasource/bal_table.csv", encoding = "UTF-8")
df<- df[!df$Sector=="",]

head(df)   #By default it shows the first 6 rows in a dataframe
colnames(df)
unique(df$Sector)



####################################AGRICULTUTRE###########################3
theme_set(theme_bw())
options(scipen = 100000000) #turns off exponential scale
df %>% 
  filter(Sector=="Agriculture") %>% 
  arrange(-OVERALL)%>% 
  group_by(Sector)%>%
  top_n(5)%>%
  ggplot(aes(reorder(Product, OVERALL), OVERALL, fill = OVERALL))+
  geom_col(show.legend = TRUE, width = 0.9)+
  geom_text(mapping = aes(label= OVERALL), position = position_dodge())+
  theme_minimal()+
  theme(axis.text.x = element_text(size = 5))+
  labs(x = NULL, y = "(TOP 5) TOTAL VALUE-AGRICULTURE")+
  scale_fill_gradient(low = "cornsilk", high = "cornsilk3")+
  theme(axis.line.y = element_line(colour = "darkslategray"),
        axis.ticks.x = element_line(colour = "darkslategray"))


####################################MANUFACTURING###########################3
theme_set(theme_bw())
options(scipen = 100000000) #turns off exponential scale
df %>% 
  filter(Sector=="Manufacturing") %>% 
  arrange(-OVERALL)%>% 
  group_by(Sector)%>%
  top_n(5)%>%
  ggplot(aes(reorder(Product, OVERALL), OVERALL, fill = OVERALL))+
  geom_col(show.legend = TRUE, width = 0.9)+
  theme_minimal()+
  theme(axis.text.x = element_text(size = 5))+
  labs(x = NULL, y = "(TOP 5) TOTAL VALUE-MANUFACTURING")+
  scale_fill_gradient(low = "khaki", high = "seagreen")+
  theme(axis.line.y = element_line(colour = "darkslategray"),
        axis.ticks.x = element_line(colour = "darkslategray"))

####################################Mining###########################3
theme_set(theme_bw())
options(scipen = 100000000) #turns off exponential scale
df %>% 
  filter(Sector=="Mining") %>% 
  arrange(-OVERALL)%>% 
  group_by(Sector)%>%
  top_n(5)%>%
  ggplot(aes(reorder(Product, OVERALL), OVERALL, fill = OVERALL))+
  geom_col(show.legend = TRUE, width = 0.9)+
  theme_minimal()+
  theme(axis.text.x = element_text(size = 5))+
  labs(x = NULL, y = "(TOP 5) TOTAL VALUE-MINING")+
  scale_fill_gradient(low = "coral", high = "coral4")+
  theme(axis.line.y = element_line(colour = "darkslategray"),
        axis.ticks.x = element_line(colour = "darkslategray"))


####################################Service Sector###########################3
theme_set(theme_bw())
options(scipen = 100000000) #turns off exponential scale
df %>% 
  filter(Sector=="Service Sector") %>% 
  arrange(-OVERALL)%>% 
  group_by(Sector)%>%
  top_n(5)%>%
  ggplot(aes(reorder(Product, OVERALL), OVERALL, fill = OVERALL))+
  geom_col(show.legend = TRUE, width = 0.9)+
  theme_minimal()+
  theme(axis.text.x = element_text(size = 5))+
  labs(x = NULL, y = "(TOP 5) TOTAL VALUE-SERVICE SECTOR")+
  scale_fill_gradient(low = "slateblue1", high = "slateblue4")+
  theme(axis.line.y = element_line(colour = "darkslategray"),
        axis.ticks.x = element_line(colour = "darkslategray"))


#########################################3. agr-mining-man-ser TOP10_closing#######################


#########################################4. EXPORT TOP 5_opening############################################

df <- read.csv("D:/ANUPAM/study/sem1/Course/1 Mathematics for Analytics/miniproject_Dr mansi/bkp/datasource/bal_table.csv", encoding = "UTF-8")
df<- df[!df$Sector=="",]

head(df)   #By default it shows the first 6 rows in a dataframe
colnames(df)
unique(df$Sector)



####################################TOP 5 AGRICULTURE EXPORT###########################3
theme_set(theme_bw())
options(scipen = 100000000) #turns off exponential scale




df %>% 
  filter(Sector=="Agriculture") %>%
  top_n(5,EXPORT)%>%
  ggplot(aes(reorder(Product, EXPORT), EXPORT, fill = EXPORT))+
  geom_col(show.legend = TRUE, width = 0.9)+
  geom_text(mapping = aes(label= EXPORT), position = position_dodge())+
  theme_minimal()+
  theme(axis.text.x = element_text(size = 5))+
  labs(x = NULL, y = "(TOP 5) EXPORT-AGRICULTURE")+
  scale_fill_gradient(low = "khaki", high = "seagreen")+
  theme(axis.line.y = element_line(colour = "darkslategray"),
        axis.ticks.x = element_line(colour = "darkslategray"))



####################################TOP 5 EXPORT MINING EXPORT###########################3
theme_set(theme_bw())
options(scipen = 100000000) #turns off exponential scale




df %>% 
  filter(Sector=="Mining") %>%
  top_n(5,EXPORT)%>%
  ggplot(aes(reorder(Product, EXPORT), EXPORT, fill = EXPORT))+
  geom_col(show.legend = TRUE, width = 0.9)+
  geom_text(mapping = aes(label= EXPORT), position = position_dodge())+
  theme_minimal()+
  theme(axis.text.x = element_text(size = 5))+
  labs(x = NULL, y = "(TOP 5) EXPORT-MINING")+
  scale_fill_gradient(low = "khaki", high = "seagreen")+
  theme(axis.line.y = element_line(colour = "darkslategray"),
        axis.ticks.x = element_line(colour = "darkslategray"))

####################################TOP 5 EXPORT MANUFACTURING EXPORT###########################3
theme_set(theme_bw())
options(scipen = 100000000) #turns off exponential scale




df %>% 
  filter(Sector=="Manufacturing") %>%
  top_n(5,EXPORT)%>%
  ggplot(aes(reorder(Product, EXPORT), EXPORT, fill = EXPORT))+
  geom_col(show.legend = TRUE, width = 0.9)+
  geom_text(mapping = aes(label= EXPORT), position = position_dodge())+
  theme_minimal()+
  theme(axis.text.x = element_text(size = 5))+
  labs(x = NULL, y = "(TOP 5) EXPORT-MANUFACTURING")+
  scale_fill_gradient(low = "khaki", high = "seagreen")+
  theme(axis.line.y = element_line(colour = "darkslategray"),
        axis.ticks.x = element_line(colour = "darkslategray"))

####################################TOP 5 EXPORT SERVICE EXPORT###########################3
theme_set(theme_bw())
options(scipen = 100000000) #turns off exponential scale




df %>% 
  filter(Sector=="Service Sector") %>%
  top_n(5,EXPORT)%>%
  ggplot(aes(reorder(Product, EXPORT), EXPORT, fill = EXPORT))+
  geom_col(show.legend = TRUE, width = 0.9)+
  geom_text(mapping = aes(label= EXPORT), position = position_dodge())+
  theme_minimal()+
  theme(axis.text.x = element_text(size = 5))+
  labs(x = NULL, y = "(TOP 5) EXPORT-SERVICE")+
  scale_fill_gradient(low = "khaki", high = "seagreen")+
  theme(axis.line.y = element_line(colour = "darkslategray"),
        axis.ticks.x = element_line(colour = "darkslategray"))

#########################################4. EXPORT TOP 5_closing############################################


#########################################5. IMPORT TOP 5_opening############################################
df <- read.csv("D:/ANUPAM/study/sem1/Course/1 Mathematics for Analytics/miniproject_Dr mansi/bkp/datasource/bal_table.csv", encoding = "UTF-8")
df<- df[!df$Sector=="",]

head(df)   #By default it shows the first 6 rows in a dataframe
colnames(df)
unique(df$Sector)



####################################TOP 5 AGRICULTURE IMPORT###########################3
theme_set(theme_bw())
options(scipen = 100000000) #turns off exponential scale




df %>% 
  filter(Sector=="Agriculture") %>%
  top_n(5,IMPORT)%>%
  ggplot(aes(reorder(Product, IMPORT), IMPORT, fill = IMPORT))+
  geom_col(show.legend = TRUE, width = 0.9)+
  geom_text(mapping = aes(label= IMPORT), position = position_dodge())+
  theme_minimal()+
  theme(axis.text.x = element_text(size = 5))+
  labs(x = NULL, y = "(TOP 5) IMPORT-AGRICULTURE")+
  scale_fill_gradient(low = "dodgerblue", high = "dodgerblue4")+
  theme(axis.line.y = element_line(colour = "darkslategray"),
        axis.ticks.x = element_line(colour = "darkslategray"))



####################################TOP 5 IMPORT MINING IMPORT###########################3
theme_set(theme_bw())
options(scipen = 100000000) #turns off exponential scale




df %>% 
  filter(Sector=="Mining") %>%
  top_n(5,IMPORT)%>%
  ggplot(aes(reorder(Product, IMPORT), IMPORT, fill = IMPORT))+
  geom_col(show.legend = TRUE, width = 0.9)+
  geom_text(mapping = aes(label= IMPORT), position = position_dodge())+
  theme_minimal()+
  theme(axis.text.x = element_text(size = 5))+
  labs(x = NULL, y = "(TOP 5) IMPORT-MINING")+
  scale_fill_gradient(low = "dodgerblue", high = "dodgerblue4")+
  theme(axis.line.y = element_line(colour = "darkslategray"),
        axis.ticks.x = element_line(colour = "darkslategray"))

####################################TOP 5 IMPORT MANUFACTURING IMPORT###########################3
theme_set(theme_bw())
options(scipen = 100000000) #turns off exponential scale




df %>% 
  filter(Sector=="Manufacturing") %>%
  top_n(5,IMPORT)%>%
  ggplot(aes(reorder(Product, IMPORT), IMPORT, fill = IMPORT))+
  geom_col(show.legend = TRUE, width = 0.9)+
  geom_text(mapping = aes(label= IMPORT), position = position_dodge())+
  theme_minimal()+
  theme(axis.text.x = element_text(size = 5))+
  labs(x = NULL, y = "(TOP 5) IMPORT-MANUFACTURING")+
  scale_fill_gradient(low = "dodgerblue", high = "dodgerblue4")+
  theme(axis.line.y = element_line(colour = "darkslategray"),
        axis.ticks.x = element_line(colour = "darkslategray"))

####################################TOP 5 IMPORT SERVICE IMPORT###########################
theme_set(theme_bw())
options(scipen = 100000000) #turns off exponential scale




df %>% 
  filter(Sector=="Service Sector") %>%
  top_n(5,IMPORT)%>%
  ggplot(aes(reorder(Product, IMPORT), IMPORT, fill = IMPORT))+
  geom_col(show.legend = TRUE, width = 0.9)+
  geom_text(mapping = aes(label= IMPORT), position = position_dodge())+
  theme_minimal()+
  theme(axis.text.x = element_text(size = 5))+
  labs(x = NULL, y = "(TOP 5) IMPORT-SERVICE")+
  scale_fill_gradient(low = "dodgerblue", high = "dodgerblue4")+
  theme(axis.line.y = element_line(colour = "darkslategray"),
        axis.ticks.x = element_line(colour = "darkslategray"))



####################################5. IMPORT TOP 5_closing###########################3



